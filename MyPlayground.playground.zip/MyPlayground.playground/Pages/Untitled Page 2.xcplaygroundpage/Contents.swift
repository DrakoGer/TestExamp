

import Foundation

//var deposit = 500000
//let rate = 11
//var profit = 0
//let period = 5
//
//for _ in 1...period {
//    let sum = (deposit * rate) / 100
//    profit += sum
//    deposit += sum
//}
//print("Сумма вклада через \(period) лет увеличится на \(profit) и составит \(deposit)")
//
//var base = 4
//var power = 1
//var result = 1
//
//for _ in 1...power {
//    result *= base
//}
//
//print("\(base) в \(power) степени равно \(result)")


//
for number in numbers {
    if number % 2 == 0 {
        print("Четные \(number)")
    }
}
//
//for number in numbers {
//    if number % 2 == 0 {
//        continue
//    }
//    print("Нечетные \(number)")
//}


//for itaration in 1...10 {
//    let randomNumber = Int.random(in: 1...10)
//    if randomNumber == 5 {
//        print("Чтоб выпало число 5, понадобилось \(itaration) итерации")
//        break
//    }
//
//}

//
//func arithmeticMean(_ numbers: Double...) -> Double {
//    var totalSum: Double = 0.0
//    for number in numbers {
//        totalSum += number
//    }
//    return totalSum / Double(numbers.count)
//}
//arithmeticMean(5, 24, 543, 34, 213)

//Родительская функция
let numbers = [1,34,5,21,6,35,8]

func filterNumber(_ value: Int, _ numbers: [Int]) -> [Int] {

    var filterSetNumber: [Int] = []

    for number in numbers {
        if number < value {
            filterSetNumber.append(number)
        }
    }
    return filterSetNumber
}
filterNumber(15, numbers)

func filterNumber(value: Int, numbers: [Int], clouser: (Int, Int) -> Bool) -> [Int] {

    var filterSetNumber: [Int] = []

    for number in numbers {
        if clouser(number, value) {
            filterSetNumber.append(number)
        }
    }
    return filterSetNumber
}

//func lesThanValue(number: Int, value: Int) -> Bool {
//    number < value
//}
//func bigerThanValue(number: Int, value: Int) -> Bool {
//    number > value
//}
//filterNumber(14, numbers, lesThanValue)
//filterNumber(14, numbers, bigerThanValue)

/*
filterNumber(
    value: 15,
    numbers: numbers,
    clouser: { (number: Int, value: Int) -> Bool in
        return number < value
    }
)

filterNumber(
    value: 15,
    numbers: numbers,
    clouser: { (number: Int, value: Int) -> Bool in
        return number > value
    }
)
*/

/*
filterNumber(
    value: 15,
    numbers: numbers,
    clouser: { (number, value) -> Bool in
        return number < value
    }
)

filterNumber(
    value: 15,
    numbers: numbers,
    clouser: { (number, value) -> Bool in
        return number > value
    }
)
*/
/*
filterNumber(
    value: 15,
    numbers: numbers,
    clouser: { (number, value) -> Bool in number < value
    }
)

filterNumber(
    value: 15,
    numbers: numbers,
    clouser: { (number, value) -> Bool in number > value }
)
*/
/*
filterNumber(
    value: 15,
    numbers: numbers,
    clouser: { $0 < $1 }
)

filterNumber(
    value: 15,
    numbers: numbers,
    clouser: { $0 > $1 }
)
*/

/*
filterNumber(value: 5, numbers: numbers) { $0 < $1 }
filterNumber(value: 5, numbers: numbers) { $0 > $1 }
*/

filterNumber(value: 15, numbers: numbers, clouser: >)
filterNumber(value: 15, numbers: numbers, clouser: <)
