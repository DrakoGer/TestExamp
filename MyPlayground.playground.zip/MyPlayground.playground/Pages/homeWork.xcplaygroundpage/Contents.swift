import Foundation

//func totalInWalet(_ moneys: Int...) -> Int {
//    var totalCashInWallet = 0
//
//    for money in moneys {
//        totalCashInWallet += money
//    }
//    return totalCashInWallet
//}
//
//var totalSumInWallet = totalInWalet(50, 200, 250, 345, 684, 445, 1044, 2000)
//
//print(totalSumInWallet)

func numberIsEven(_ number: Int) -> Bool {
    return number % 2 == 0
}
numberIsEven(4)

//func numberDevidOnThree(_ number: Int) -> Bool {
//
//    return number % 3 == 0
//}
//numberDevidOnThree(6)
//
//
//
////func randomNumber(from x: Int, to y: Int) -> [Int] {
////    var newNumber: [Int] = []
////    for number in x...y {
////        newNumber.append(number)
////    }
////    return newNumber
////}
////func randomNumber(from x: Int, to y: Int) -> [Int] {
////    var newNumber: Set<Int> = []
////    for number in x...y {
////        newNumber.insert(number)
////    }
////    return Array(newNumber)
////}
////let numbers = randomNumber(from: 1, to: 100)
////print(numbers)
//
//func filterAllNumber(from x: Int, to y: Int) -> [Int] {
//    var newNumber: [Int] = []
//
//    for number in x...y {
//        if number % 2 != 0 && number % 3 != 0{
//            newNumber.append(number)
//        }
//    }
//    return newNumber
//}
//
//let numbers = filterAllNumber(from: 1, to: 100)
//
//print(numbers)
//
//
//
//
//func filterAnyNumber(number: [Int], clouser: (Int) -> Bool) -> [Int] {
//    var newNumbers: [Int] = []
//    for number in numbers {
//        if !clouser(number) {
//            newNumbers.append(number)
//        }
//    }
//    return newNumbers
//}
//
//filterAnyNumber(number: numbers, clouser: numberIsEven)
//
//filterAnyNumber(number: numbers, clouser: numberDevidOnThree)


