import Foundation


//let postTitle = "Calasses"
//let postBody = "Text of the article"
//let postAuthor = "Yura Karapetyan"
//
//let postTitle2 = "Properties of classes"
//let postBody2 = "A lot of text"
//let postAuthor2 = postAuthor
//
//class Post {
//    var title = ""
//    var body = ""
//    var author = ""
//    var numberOfComents = 0
//    var comments: [String] = []
//
//    func addComment(_ comment: String) {
//        print(comment)
//        numberOfComents += 1
//        comments.append(comment)
//
//    }
//}
//
//let firstPost = Post()
//
//firstPost.title = "This is my first post"
//firstPost.body = "Hello"
//firstPost.author = postAuthor
//firstPost.addComment("Thanks you so much")
//firstPost.addComment("New comment")
//
//print("Author \(firstPost.author) has published new post '\(firstPost.title)' with text '\(firstPost.body)'")
//
//
//let secondPost = Post()
//
//secondPost.title = "Second Post"
//secondPost.body = "A lot of text"
//secondPost.author
//secondPost.addComment("hh")
//
//print("Author \(firstPost.author) has published new post '\(firstPost.title)' with text '\(firstPost.body)'")
//
//print("Author \(secondPost.author) has published new post '\(secondPost.title)' with text '\(secondPost.body)'")
//
//print("The number of comment for the post \(firstPost.title) is \(firstPost.numberOfComents)")
//print("The number of comment for the post \(secondPost.title) is \(secondPost.numberOfComents)")
//
//firstPost === secondPost
//
//class Human {
//    let name: String
//    let age: Int
//
//
//    init(name: String, age: Int) {
//        self.name = name
//        self.age = age
//    }
//
//    func walk() {
//        print("I can walk")
//    }
//
//    func sleep() {
//        print("I need sleep")
//    }
//
//    func eat() {
//        print("I need food")
//    }
//}
//
//let somePerson = Human(name: "Yura", age: 24)
//
//
//somePerson.name
//somePerson.age
//
//
//class Child: Human {
//
//}
//
//let littleBoy = Child(name: "Tom", age: 4)
//littleBoy.sleep()
//littleBoy.eat()
//littleBoy.walk()
//
//class SchoolChild: Child {
//
//    func schooling() {
//        if age >= 6 && age <= 17 {
//            print("I have to go to school")
//        } else {
//            print("I'm still too early in school")
//        }
//    }
//}

//enum Color: String {
//    case red
//    case black
//    case green
//}
//
//class Transport {
//    let year: Int
//    var color: Color = .black
//    let numberOfSeats: Int
//
//    init(year: Int, numbers: Int) {
//        self.year = year
//        self.numberOfSeats = numbers    }
//}
//
//let transport = Transport(year: 2005, numbers: 5)
//
//print(transport.year)
//transport.color = .red
//
//
//class Car: Transport {
//    let vin: String
//    var number: String?
//    var music: Bool = false
//
//    init(vin:String, year: Int, numbers: Int) {
//        self.vin = vin
//        super.init(year: year, numbers: numbers)
//    }
//}
//
//let car = Car(vin: "s2s343dj2i", year: 2020, numbers: 4)
//print(car.vin)


//class Human {
//
//    var age = 25
//    var name = "Maria"
//
//    func move() {
//        print("\(name) is moving")
//    }
//}
//
//var maria = Human()
//
//maria.age


//func sumOfPositives(_ number: Double ) -> Double {
//    var result: Double = 0
//    
//    if number <= 0 {
//        result = abs(number)
//    } else if number >= 0 {
//        result = -(number)
//    }
//    return result
//}
//
//let resultate = sumOfPositives(-6)
//
//print(resultate)
//
//abs(-2)

